import{a as t}from"../chunks/uT6aD3Jl.js";export{t as start};
