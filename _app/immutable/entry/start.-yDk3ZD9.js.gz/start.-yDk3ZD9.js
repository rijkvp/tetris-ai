import{a as t}from"../chunks/1xJDnU6d.js";export{t as start};
