import{a as t}from"../chunks/DqmtG_Fj.js";export{t as start};
