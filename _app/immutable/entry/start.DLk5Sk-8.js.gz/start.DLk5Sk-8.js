import{a as t}from"../chunks/C0I5rvAN.js";export{t as start};
